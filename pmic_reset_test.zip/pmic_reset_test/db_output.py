import sqlite3
import os
import time
from typing import NamedTuple, List, Any
import ble_service_handler_module.blehandler.process as proc
import threading

directory_path = os.path.join("/mnt/mmcblk0p4", "NRF")

if not os.path.exists(directory_path):
    os.makedirs(directory_path)
    print(f"Directory created!")


DB_PATH = os.path.join(directory_path, "NRFData.db")
BLE_SNIFFER_DATA_FOLDER_PATH = os.path.join(directory_path, "BLE_SNIFFER/PRO2")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS spacesense_data(id INTEGER PRIMARY KEY AUTOINCREMENT,tagSerial TEXT, timestamp INT,occupancy_data INT, rssi INT, batteryVoltage INT, minSensorVal INT, maxSensorVal INT)")
    cur.execute("CREATE TABLE IF NOT EXISTS ble_tracking(mac TEXT, timestamp INTEGER,rssi INTEGER,type INTEGER, company_id TEXT)")
    cur.execute("CREATE TABLE IF NOT EXISTS bledevices(mac TEXT, deviceType INTEGER)")
    cur.execute("CREATE TABLE IF NOT EXISTS se_button(rssi INTEGER, timestamp INTEGER)")
    cur.execute("CREATE TABLE IF NOT EXISTS fw_version(timestamp INTEGER, version TEXT)")
    cur.execute("CREATE TABLE IF NOT EXISTS current_mode(mode INTEGER)")
    cur.execute("CREATE TABLE IF NOT EXISTS reboot_count(timestamp INTEGER, count INTEGER)")

    conn.commit()
    conn.close()

def write_spacesense_data_into_db(spacesense_data : proc.notif_utils.SpaceSenseData):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO spacesense_data(tagSerial,timestamp,occupancy_data, rssi, batteryVoltage, minSensorVal, maxSensorVal) values(?,?,?,?,?,?,?)",
        [
            spacesense_data.MAC,
            int(time.time()),
            spacesense_data.occupancy_data,
            spacesense_data.rssi,
            spacesense_data.battery_val,
            spacesense_data.min_val,
            spacesense_data.max_val
        ]
    )
    conn.commit()
    conn.close()

def write_se_button_data_into_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO se_button(rssi,timestamp) values(?,?)",
        [
            1,
            int(time.time())
        ]
    )
    conn.commit()
    conn.close()


def get_ble_sniffer_data_db_path():
    if not os.path.exists(BLE_SNIFFER_DATA_FOLDER_PATH):
        os.makedirs(BLE_SNIFFER_DATA_FOLDER_PATH)
    date_hour_str = time.strftime("%Y-%m-%d_%H")
    return os.path.join(BLE_SNIFFER_DATA_FOLDER_PATH, f"SnifferData_{date_hour_str}.db")

def init_ble_sniffer_data_db(db_path: str = None):
    """Ensure the ble_tracking table exists in the hourly sniffer DB.

    If db_path is None the path is computed from the current hour. This
    function is idempotent and safe to call repeatedly.
    """
    try:
        if db_path is None:
            db_path = get_ble_sniffer_data_db_path()

        existed_before = os.path.exists(db_path)
        if not existed_before:
            print(f"Creating new BLE sniffer database for current hour: {db_path}")

        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        # Always attempt to create the table (idempotent). This handles the
        # case where the file exists but the table is missing.
        cur.execute("""
            CREATE TABLE IF NOT EXISTS ble_tracking (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mac TEXT,
                timestamp INTEGER,
                rssi INTEGER,
                addr_type INTEGER,
                company_id TEXT
            )
        """)
        conn.commit()
    except Exception as e:
        print(f"init_ble_sniffer_data_db error for {db_path}: {e}")
        raise
    finally:
        try:
            conn.close()
        except Exception:
            pass
    # else:
        # print(f"Using existing BLE sniffer database: {db_path}")

_scheduler_thread = None
_scheduler_stop_event = threading.Event()

def _scheduler_worker():
    while not _scheduler_stop_event.is_set():
        try:
            init_ble_sniffer_data_db()
        except Exception as e:
            print(f"Scheduler error: {e}")
        now = time.time()
        next_hour = (now // 3600 + 1) * 3600
        sleep_seconds = max(0, next_hour - now)
        # Wait with ability to wake early if stop requested
        _scheduler_stop_event.wait(timeout=sleep_seconds)

def start_scheduler():
    global _scheduler_thread, _scheduler_stop_event
    if _scheduler_thread and _scheduler_thread.is_alive():
        return
    _scheduler_stop_event.clear()
    _scheduler_thread = threading.Thread(target=_scheduler_worker, daemon=True)
    _scheduler_thread.start()

def stop_scheduler():
    global _scheduler_thread, _scheduler_stop_event
    _scheduler_stop_event.set()
    if _scheduler_thread:
        _scheduler_thread.join(timeout=2)
        _scheduler_thread = None

def write_sniffer_data_into_db(sniffer_data : proc.notif_utils.SnifferData):
    # Compute the DB path once to avoid hour-rollover races, ensure the
    # table exists in that exact file, then write to the same file.
    ble_sniffer_data_db_path = get_ble_sniffer_data_db_path()
    init_ble_sniffer_data_db(ble_sniffer_data_db_path)
    conn = sqlite3.connect(ble_sniffer_data_db_path)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO ble_tracking(mac,timestamp,rssi,addr_type, company_id) values(?,?,?,?,?)",
        [sniffer_data.MAC, int(time.time()), sniffer_data.rssi, sniffer_data.addr_type, sniffer_data.company_id]
    ) 
    conn.commit()
    conn.close()

def write_exclusion_data_into_db(exclusion_data : proc.notif_utils.StaffExclusionData):
    pass

def get_staffexclusion_list() -> List[Any]:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("select * from bledevices where deviceType = '0'")
    result = cur.fetchall()
    conn.close()
    return result

class FirmwareData(NamedTuple):
    version: str

def write_firmware_data_into_db(firmware_data : FirmwareData):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO fw_version(timestamp, version) values(?,?)",
        [int(time.time()), firmware_data.version] if firmware_data.version else [int(time.time()), "Unknown Version"]
    )
    conn.commit()
    conn.close()

class CurrentModeData(NamedTuple):
    mode: int

def get_current_mode() -> CurrentModeData:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT mode FROM current_mode")
    result = cur.fetchone()
    conn.close()
    
    return CurrentModeData(mode=result[0]) if result else CurrentModeData(mode=-1)

def write_current_mode_into_db(current_mode_data: CurrentModeData):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # Check if table has any rows
    cur.execute("SELECT COUNT(*) FROM current_mode")
    count = cur.fetchone()[0]

    if count == 0:
        # Insert first entry
        cur.execute(
            "INSERT INTO current_mode (mode) VALUES (?)",
            [current_mode_data.mode]
        )
    else:
        # Update existing entry
        cur.execute(
            "UPDATE current_mode SET mode = ?",
            [current_mode_data.mode]
        )

    conn.commit()
    conn.close()


def get_reboot_count_from_db() -> int:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT count FROM reboot_count ORDER BY timestamp DESC LIMIT 1")
    result = cur.fetchone()
    conn.close()
    
    return result[0] if result else 0

def write_reboot_count_into_db(reboot_count: int):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO reboot_count(timestamp, count) values(?,?)",
        [int(time.time()), reboot_count]
    )
    conn.commit()
    conn.close()

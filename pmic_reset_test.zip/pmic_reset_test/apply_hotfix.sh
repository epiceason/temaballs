#!/bin/sh

set -u  # fail on unset variables

step() {
    echo ""
    echo "▶ $1"
}

fail() {
    echo ""
    echo "❌ FAILED: $1"
    exit 1
}

run() {
    step "$1"
    sh -c "$1" || fail "$1"
}

echo "===== Applying Hotfix ====="

# 1. chmod scripts
run "chmod +x *.sh"

# 2. Copy systemd service
run "cp bootup_log_test.service /etc/systemd/system/"

# 3. Enable service
run "systemctl enable bootup_log_test.service"

# 4. Start service
run "systemctl start bootup_log_test.service"

# 5. Copy db_output.py
run "cp db_output.py /usr/lib/python3/dist-packages/ble_service_handler_module/blehandler_runtime/"

# 6. Copy ping_esp32_direct.py
run "cp ping_esp32_direct.py /usr/lib/python3/dist-packages/ble_service_handler_module/blehandler_runtime/"

# 7. Copy firmware
run "cp pro2_nrf_firmware_v2.3.1.signed.bin \
     /usr/lib/python3/dist-packages/ble_service_handler_module/blehandler_runtime/firmware/"

# 8. Restart BLE service
run "systemctl restart ble_service_handler_module.service"

# 9. Wait 5 seconds
step "Waiting 5 seconds"
sleep 5

# 10. Firmware check
run "python3 -m ble_service_handler_module.blehandler_runtime.fw_check"

# 11. Install cron job
run "cp crontabBLEServiceHandlerModule /etc/cron.d/"

# 12. Restart cron
run "systemctl restart cron.service"

echo ""
echo "✅ Hotfix applied successfully"
exit 0

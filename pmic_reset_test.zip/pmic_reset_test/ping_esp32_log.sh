#!/bin/bash

LOG_FILE="/home/pi/pmic_reset_test/ping_esp32_log.txt"

# Print timestamp
echo "[$(date '+%Y-%m-%d %H:%M:%S')]" >> "$LOG_FILE"

# Run the Python command and append output & errors
/usr/bin/python3 -m ble_service_handler_module.blehandler_runtime.ping_esp32_direct 240 >> "$LOG_FILE" 2>&1

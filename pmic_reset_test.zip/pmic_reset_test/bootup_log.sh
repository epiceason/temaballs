#!/bin/sh

OUT_DIR="/home/pi/pmic_reset_test/"
OUT_FILE="$OUT_DIR/bootup_log.txt"

# Create directory if it doesn't exist
mkdir -p "$OUT_DIR"

KEYWORD="$1"

if [ -z "$KEYWORD" ]; then
    echo "Usage: $0 <keyword>"
    exit 1
fi

# ===== CONFIG =====
TIMEOUT_SEC=120    # max wait time for NTP sync
SLEEP_INTERVAL=1
# ==================

ELAPSED=0
SYNCED=0

# Wait for time sync with timeout
while [ "$ELAPSED" -lt "$TIMEOUT_SEC" ]; do
    if timedatectl show -p NTPSynchronized --value 2>/dev/null | grep -q yes; then
        SYNCED=1
        break
    fi
    sleep "$SLEEP_INTERVAL"
    ELAPSED=$((ELAPSED + SLEEP_INTERVAL))
done

TIMESTAMP="$(date '+%Y-%m-%d %H:%M:%S')"

if [ "$SYNCED" -eq 1 ]; then
    echo "$TIMESTAMP | $KEYWORD | time synced after ${ELAPSED}s" >> "$OUT_FILE"
else
    echo "$TIMESTAMP | $KEYWORD | WARNING: time sync stuck after ${TIMEOUT_SEC}s" >> "$OUT_FILE"
fi

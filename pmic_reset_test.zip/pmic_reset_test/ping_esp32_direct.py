# At top of file: add imports
import time
import struct
import argparse
import threading
import subprocess
import sys
import logging

from . import db_output as db_out

import ble_service_handler_module.blehandler.BLE_uart_handler as ble
from ble_service_handler_module.blehandler import ble_commands as ble_cmd

from utility_module.utility import ParamHandler

# configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# get IOBOARD_VER with safe handling
IOBOARD_VER = ""
try:
    res = ParamHandler.sqlite3_cmd("/home/pi/Raspicam/raspicam",
                                   "select value from cameraSetting where param='IoBoard';",
                                   "select")
    IOBOARD_VER = res[0] if res else ""
    logger.debug("IOBoard version from DB: %s", IOBOARD_VER)
except Exception as e:
    logger.warning("Failed to read IOBoard version from DB: %s", e)
    IOBOARD_VER = ""

# Default TTY choices (allow override via CLI)
TTY_PORT = "/dev/ttyS1"
if IOBOARD_VER and IOBOARD_VER.lower() == "v1":
    TTY_PORT = "/dev/ttyS1"  # NRF default on older boards
elif IOBOARD_VER and ("v10" in IOBOARD_VER.lower()):
    TTY_PORT = "/dev/ttyS2"  # ESP default on some boards
# else leave TTY_PORT as /dev/ttyS1

parser = argparse.ArgumentParser(description="Ping ESP32 via BLE UART (direct).")
parser.add_argument("count", type=int, help="ping count to send")
parser.add_argument("--no-service-control", action="store_true",
                    help="do not stop/start the system service; useful for manual runs and Windows")
args = parser.parse_args()
recv_resp = threading.Event()

SERVICE_NAME = "ble_service_handler_module.service"
stop_cmd = ["sudo", "systemctl", "stop", SERVICE_NAME]
start_cmd = ["sudo", "systemctl", "start", SERVICE_NAME]

reboot_count = None

def error_exit(message: str, code: int = 1) -> None:
    logger.error(message)
    sys.exit(code)

def run_or_fail(command, check_output=False):
    try:
        if check_output:
            return subprocess.check_output(command, stderr=subprocess.STDOUT, text=True)
        else:
            subprocess.check_call(command)
            return True
    except subprocess.CalledProcessError as e:
        output = getattr(e, "output", "")
        logger.error("Command failed: %s\n%s", " ".join(command), output)
        return False

# optionally stop service first before running this script
if not args.no_service_control:
    ok = run_or_fail(stop_cmd, check_output=False)
    if ok:
        logger.info("%s stopped successfully", SERVICE_NAME)
    else:
        logger.warning("Failed to stop %s (continuing because service control enabled)", SERVICE_NAME)
else:
    logger.info("Skipping service stop/start because --no-service-control was provided")

def ping_esp32_cb(payload: ble.Payload):
    logger.info("Received a response")
    logger.debug("Payload: number=%s data=%s", getattr(payload, "number", None), getattr(payload, "data", None))
    try:
        global reboot_count
        # sample value: 
        # resp->len = sizeof(count) + sizeof(reboot_count);
        # memcpy(resp->buffer, &count, sizeof(count));
        # memcpy(resp->buffer + sizeof(count), &reboot_count, sizeof(reboot_count));
        # where count is uint16_t and reboot_count is uint32_t
        count, reboot_count = struct.unpack("<HI", payload.data)

        logger.info("Received from ESP: [%d,%d]", count, reboot_count)
    except Exception as e:
        logger.warning("Failed to parse payload.data to int: %s", e)
    recv_resp.set()

bt_handler = None
try:
    bt_handler = ble.BLEReceiver(TTY_PORT)
    ble_cmd.ping_esp32(bt_handler, args.count, ping_esp32_cb)
    bt_handler.start()

    # wait for response with timeout to avoid blocking when run from cron
    if recv_resp.wait(timeout=30):
        logger.info("Response received! Exiting...")
    else:
        logger.info("No response received within timeout (30s), exiting...")

except Exception as e:
    logger.exception("Unexpected exception while running ping: %s", e)
finally:
    # ensure we stop the handler only if it was created
    if bt_handler is not None:
        try:
            bt_handler.stop()
        except Exception:
            logger.exception("Error stopping bt_handler")

# check if the reboot_count is differetn from last stored value
# and store it into the database if so
last_reboot_count = db_out.get_reboot_count_from_db()
if last_reboot_count != reboot_count:
    db_out.write_reboot_count_into_db(reboot_count)

# optionally restart service after running this test script
if not args.no_service_control:
    ok = run_or_fail(start_cmd, check_output=False)
    if ok:
        logger.info("%s started successfully", SERVICE_NAME)
    else:
        error_exit(f"Failed to start {SERVICE_NAME}")

logger.info("Completed direct ping esp32")
